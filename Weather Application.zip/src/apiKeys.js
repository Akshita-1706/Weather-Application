module.exports = {
    key : "11de66c814e293cffb036a326003629f",
    base : "https://api.openweathermap.org/data/2.5/"
}